import UIKit

struct MathOperation{
    var units: String?
    
    var operation: (Double, Double) -> Double = {
        return $0 + $1
    }
    
    init?(units: String){
        if let units = self.units{
            self.units = units
        }
        else{
            return nil
        }
    }
}
