import UIKit

func check(value: Int) -> String?{
    if(value < 0 || value == 0){
        return nil
    }
    
    let myString = String(value)
    return myString
}

print(check(value: 0) ?? "Was Nil")

let numberString1:String? = check(value: 5)
let numberString2:String? = check(value: 6)
